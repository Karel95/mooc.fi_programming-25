---
path: '/part-7'
title: 'Part 7'
overview: true
hidden: false
separator_after: "Advanced Course in Programming"
---

<pages-in-this-section></pages-in-this-section>

<exercises-in-this-section></exercises-in-this-section>
