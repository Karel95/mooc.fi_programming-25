---
path: '/all-exercises'
title: 'All exercises'
hidden: false
hide_in_sidebar: false
sidebar_priority: 5000
course_info_page: true
---

<exercises-in-all-sections></exercises-in-all-sections>
