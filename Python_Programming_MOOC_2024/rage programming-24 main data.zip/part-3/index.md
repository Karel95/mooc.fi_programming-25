---
path: '/part-3'
title: 'Part 3'
overview: true
hidden: false
---

<pages-in-this-section></pages-in-this-section>

<exercises-in-this-section></exercises-in-this-section>
