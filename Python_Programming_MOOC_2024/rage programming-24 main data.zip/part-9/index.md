---
path: '/part-9'
title: 'Part 9'
overview: true
hidden: false
---

<pages-in-this-section></pages-in-this-section>

<exercises-in-this-section></exercises-in-this-section>
